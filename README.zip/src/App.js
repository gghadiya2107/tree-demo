import logo from "./logo.svg";
import "./App.css";
import Chart from "./component/Chart";

function App() {
  return (
    <div className="App">
      <div className="container">
        <Chart />
      </div>
    </div>
  );
}

export default App;
